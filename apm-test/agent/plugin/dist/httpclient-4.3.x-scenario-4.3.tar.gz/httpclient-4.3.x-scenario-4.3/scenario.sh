#!/usr/bin/env bash

echo "start successfully"